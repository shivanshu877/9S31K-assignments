import React from "react";
import "./Crousel.css";
const Crousel = () => {
  return (
    <div className="crousel">
      <img
        src="https://rukminim2.flixcart.com/fk-p-flap/1000/170/image/cc633426b89ad841.png?q=20"
        alt="Crousel"
      />
    </div>
  );
};

export default Crousel;
